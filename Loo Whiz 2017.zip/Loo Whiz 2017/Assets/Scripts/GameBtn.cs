﻿using UnityEngine;
using System.Collections;

public class GameBtn : MonoBehaviour {

    public void Mop()
    {
        //Character Mop if on Mess
    }
    public void FillRoll()
    {
        //Character FillRoll if on ToiletBowl
    }
    public void Sweep()
    {
        //Character Sweep if on Mess
    }
    public void Wipe()
    {
        //Character wipe if on Mess
    }
}
